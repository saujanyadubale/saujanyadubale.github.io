"""Regenerate presentation plots from v0.6 benchmark and exported forecast JSON."""
from __future__ import annotations
import json
import sys
from pathlib import Path
from statistics import mean
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def benchmark_plot(result_path:Path,output_dir:Path):
    data=json.loads(result_path.read_text())
    for signal,unit in [('bus_voltage_v','V'),('temperature_c','°C')]:
        records=[r for r in data['campaigns'] if r['signal']==signal]
        methods=['persistence','physics_baseline','linear_trend','gradient_boosting']
        means=[mean(r['mae'] for r in records if r['method']==m) for m in methods]
        plt.figure(figsize=(9,4.7))
        plt.bar(range(4),means)
        plt.xticks(range(4),['Persistence','Physics','Linear trend','Gradient boosting'])
        plt.ylabel('Campaign-average absolute prediction error ('+unit+')')
        plt.title('5-minute held-out forecasts · '+('Bus voltage' if signal=='bus_voltage_v' else 'Temperature'))
        plt.grid(axis='y',alpha=.18)
        plt.tight_layout()
        plt.savefig(output_dir/('forecast_mae_voltage.png' if signal=='bus_voltage_v' else 'forecast_mae_temperature.png'),dpi=145)
        plt.close()


def example_plot(input_file:Path,output_file:Path):
    data=json.loads(input_file.read_text());s=data['meta']['signal']
    tel=data['telemetry']; f=[p for p in data['forecasts'] if p['target_time_s']<=tel[-1]['time_s']]
    fig,ax=plt.subplots(figsize=(10,4.8))
    ax.plot([p['time_s']/60 for p in tel],[p[s] for p in tel],label='Observed')
    ax.plot([p['target_time_s']/60 for p in f], [p['predictions']['gradient_boosting'] for p in f],label='ML forecast at future target time')
    ax.plot([p['target_time_s']/60 for p in f], [p['predictions']['linear_trend'] for p in f],label='Linear trend forecast',alpha=.85)
    ax.fill_between([p['target_time_s']/60 for p in f],[p['ml_lower'] for p in f],[p['ml_upper'] for p in f],alpha=.15,label='Synthetic calibration band')
    ax.axhline(data['limit'],linestyle='--',label='Requirement limit')
    ax.set(xlabel='Simulation time (minutes)',ylabel=s+' ('+('V' if s=='bus_voltage_v' else '°C')+')',
           title='5-minute causal forecast · '+data['scenario']['scenario'])
    ax.grid(alpha=.18);ax.legend(fontsize=8,loc='best')
    fig.tight_layout();fig.savefig(output_file,dpi=145);plt.close(fig)

if __name__=='__main__':
    out=Path('results/v0.6');out.mkdir(parents=True,exist_ok=True)
    benchmark_plot(out/'forecast_benchmark.json',out)
    for scenario in ('example_voltage','example_thermal'):
        example_plot(out/(scenario+'.json'),out/(scenario+'.png'))
    print('Saved four graphics to',out)
